import requests
from django.shortcuts import render
from .models import City
from .forms import CityForm

def hello(request):
    url = 'http://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=329fab3761f0d254757fbe783c281934'
    city='İzmir'
    r=requests.get(url.format(city)).json()
    
    # if request.method == 'POST':
    #     form = CityForm(request.POST)
    #     form.save()

    # form = CityForm()

    # cities = City.objects.all()

    # weather_data = []

    # for city in cities:

    #     r = requests.get(url.format(city)).json()

    city_weather = {
            'city' : city,
            'temperature' : r['main']['temp'],
            'description' : r['weather'][0]['description'],
            'icon' : r['weather'][0]['icon'],
        }

    #     weather_data.append(city_weather)
    print(city_weather)
    context = {'city_weather' : city_weather}
    return render(request, 'index.html',context)